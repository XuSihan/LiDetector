from _2019.diffyq.part5.staging import *

OUTPUT_DIRECTORY = "diffyq/part5"
SCENES_IN_ORDER = [
]