import tutorials.keras.text_NER as ft


def main():
    ft.main()


if __name__ == "__main__":
    main()
